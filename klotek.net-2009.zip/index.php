<? 
echo ("<?xml version='1.0' encoding='iso-8859-2'?>");
?>

<!DOCTYPE html
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title> Klotek.net - Braino Edition </title>
		<style type="text/css">
			@import url("css/default.css");
		</style>
</head>
<body bgcolor="#333333" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF">
<div align="center">
<table border="0" height="50">
<tr><td><!-- Blank table--></td></tr>
</table>
<table border="0" height="100">
<tr><td><div align="center"><img src="klotek.gif"></div></td></tr>
<tr><td><div align="center"><img src="braino.gif"></div></td></tr>
<tr height="15px"><td><hr></td></tr>
<tr><td>
<?
include ('scripting/linki.php');
?>
</td></tr>
<tr height="15px"><td><hr></td></tr>
<tr><td>
	<table id="links"><tr>
	<td><b>Active Projects:</b></td> <td><a href="telv.html">TelV</a> | <a href="/forum">CooL</a> | <a href="blog.php">Blog</a></td> 
</tr>	<tr><td><b>Future Projects:</td><td><a href="#">Who Killed a Bambi?</a> </td></tr><tr>
<td width="120"><b>Abandoned Projects:</b></td> <td>
	Lavishy City 17
	</td>
	</tr>

	</table>
	</font>
</td></tr>
<tr height="15px"><td><hr></td></tr>
<tr><td width="400"><div style="margin-left: 10px; margin-right: 25px;"><b>Update status: 21:04 2009-03-03</b><br />
Now real online. <br />
http://klotek.home.pl/<br />
soon http://klotek.net/ (in 2-3 days I guess)<br />
</div></td></tr>
<tr height="15px"><td><hr></td></tr>
<tr><td>
<font size="-3" face="verdana"><div align="center">contact: <a href="mailto:klotek@gmail.com" style="text-decoration: none;">klotek &lt; at &gt; gmail.com</a> |
gg: <a href="gg:5931986" style="text-decoration: none;">5931986</a> |
icq: <a href="http://www.icq.com/472924814" style="text-decoration: none;">472924814</a></font></div>
</td></tr>
<tr><td><div align="center"><font size="-3" face="verdana">copyrights by <a href="mailto:klotek@gmail.com" style="text-decoration: none;">klotek</a> 2001-2009 | Created by Konrad Knitter</div></td></tr>
</table>


</font>
</div>
</body>
</html>