<?
$dbc = mysql_connect('localhost', 'root', 'mangos');
mysql_select_db('telviewer');
?>