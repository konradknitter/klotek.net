<?
echo ('<p align="center">contact: klotek < at > gmail.com | gg: 5931986 | icq: 472924814 | copyrights by klotek 2001-2009 | Created by Konrad Knitter</p>');
?>