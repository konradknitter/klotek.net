<?
echo "<div style='float:left;'> 
<a href='?' style='text-decoration: none; font-weight: 800;'>Blog</a> |  Strona w Przebudowowie :)";
// <a href='/' style='text-decoration: none; font-weight: 800;'>Home</a> | 

//  <a href='#' style='text-decoration: line-through;'>About</a> | 
//<a href='#' style='text-decoration: line-through;'>FAQ</a>  |
//<a href='#' style='text-decoration: line-through;'>Portfolio</a> 
echo "</div>
<div style='float:right;'>
<a href='login' style='text-decoration: line-through;'>Logowanie</a> | 
<a href='http://klotek.home.pl/forum' style='text-decoration: none;'>Forum</a> 
</div>";
?>